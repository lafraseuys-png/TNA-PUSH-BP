'use strict';
/* =====================================================================
   TNA POS EDGE - the installed till
     - Serves the POS screen on http://localhost:3099 (install it as an app in Chrome / Edge)
     - Online: every call goes to the company's server, and the till keeps a local copy
     - Offline: the till answers from that copy and queues the work; it is sent when the
       connection is back, with the real time and the offline slip number
     - The cashier signs in here, online or offline (with their normal password)
   Settings come from pos-edge.config.json, downloaded with the Download App button.
   ===================================================================== */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const bcrypt = require('bcryptjs');

const Store = require('./lib/store');
const Cloud = require('./lib/cloud');
const Offline = require('./lib/offline');

const VERSION = '1.0.0';
const WEB_FILES = ['POS.html', 'pos.js', 'POSSlips.js', 'theme.js', 'css/assets.css'];

// ---------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------
const appDir = path.dirname(process.execPath.toLowerCase().endsWith('node.exe') || process.execPath.toLowerCase().endsWith('node') ? __filename : process.execPath);
const dataDir = path.join(appDir, 'data');
const logFile = path.join(dataDir, 'edge.log');

function log(...args) {
    const line = `[${new Date().toISOString()}] ${args.map(a => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}`;
    console.log(line);
    try { fs.appendFileSync(logFile, line + '\n'); } catch (e) {}
}

function loadConfig() {
    const file = path.join(appDir, 'pos-edge.config.json');
    if (!fs.existsSync(file)) {
        console.error(`\nSETUP FILE MISSING\n\n  ${file}\n\nDownload the package again from the POS screen ("Install App") and keep\npos-edge.config.json next to TNA-POS-Edge.exe.\n`);
        process.exit(1);
    }
    const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
    cfg.version = VERSION;
    cfg.edge = cfg.edge || {};
    cfg.edge.localPort = cfg.edge.localPort || 3099;
    return cfg;
}

// ---------------------------------------------------------------------
// Windows: install / remove the till so it starts with the PC
//   TNA-POS-Edge.exe --install    (run as administrator)
//   TNA-POS-Edge.exe --uninstall
// A scheduled task at start-up is used, so nothing extra has to be installed.
// ---------------------------------------------------------------------
const TASK_NAME = 'TNA POS Edge';
if (process.argv.includes('--install') || process.argv.includes('--uninstall')) {
    const { execFileSync } = require('child_process');
    const remove = process.argv.includes('--uninstall');
    try {
        if (remove) {
            execFileSync('schtasks', ['/Delete', '/TN', TASK_NAME, '/F'], { stdio: 'inherit' });
            console.log('\nTNA POS Edge removed. It will not start with this PC again.\n');
        } else {
            execFileSync('schtasks', ['/Create', '/SC', 'ONSTART', '/RL', 'HIGHEST', '/RU', 'SYSTEM',
                '/TN', TASK_NAME, '/TR', `"${process.execPath}"`, '/F'], { stdio: 'inherit' });
            execFileSync('schtasks', ['/Run', '/TN', TASK_NAME], { stdio: 'inherit' });
            console.log('\nTNA POS Edge installed and started.\nOpen http://localhost:3099 in Chrome or Edge.\n');
        }
        process.exit(0);
    } catch (e) {
        console.error('\nCould not ' + (remove ? 'remove' : 'install') + ' the till: ' + e.message +
            '\nRight-click install.cmd and choose "Run as administrator".\n');
        process.exit(1);
    }
}

const config = loadConfig();
fs.mkdirSync(dataDir, { recursive: true });
const store = new Store(dataDir);
const cloud = new Cloud(config, log);

// ---------------------------------------------------------------------
// Sessions: the cashier signs in on this till
// ---------------------------------------------------------------------
function newSessionToken() { return crypto.randomBytes(24).toString('hex'); }

function sessionUser(req) {
    const header = String(req.headers['authorization'] || '');
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return null;
    const s = store.sessions()[token];
    if (!s) return null;
    return s;
}

async function signIn(username, password) {
    const user = String(username || '').trim();
    const pass = String(password || '');

    // 1. Online: the company's server decides, and we keep the password hash for offline use
    if (cloud.online || (await ping())) {
        try {
            const res = await cloud.call('POST', '/api/login', { username: user, password: pass }, { 'Content-Type': 'application/json' }, 15000);
            if (res.ok) {
                const body = await res.json();
                const cache = store.cache();
                const known = cache ? (cache.users || []).find(u => String(u.Username).toLowerCase() === user.toLowerCase()) : null;
                return keepSession({
                    userId: known ? known.UserID : (body.userId || null),
                    username: user,
                    displayName: known ? known.DisplayName : user,
                    rights: known ? known.rights : {},
                    canCashOut: known ? !!known.CanCashOut : false,
                    canCashReturn: known ? !!known.CanCashReturn : false,
                    canAccountReturn: known ? !!known.CanAccountReturn : false
                });
            }
            if (res.status === 401) throw new Error('Wrong username or password.');
        } catch (e) {
            if (/Wrong username/.test(e.message)) throw e;
            log('Online sign-in not possible, trying the till copy:', e.message);
        }
    }

    // 2. Offline: check the password against the hash from the last download
    const cache = store.cache();
    const known = cache ? (cache.users || []).find(u => String(u.Username).toLowerCase() === user.toLowerCase()) : null;
    if (!known) throw new Error('This user is not on this till yet. Connect to the internet and sign in once.');
    if (!known.PasswordHash || !bcrypt.compareSync(pass, known.PasswordHash)) throw new Error('Wrong username or password.');
    return keepSession({
        userId: known.UserID, username: known.Username, displayName: known.DisplayName, rights: known.rights || {},
        canCashOut: !!known.CanCashOut, canCashReturn: !!known.CanCashReturn, canAccountReturn: !!known.CanAccountReturn
    });
}

function keepSession(user) {
    const token = newSessionToken();
    const sessions = store.sessions();
    sessions[token] = Object.assign({ at: new Date().toISOString() }, user);
    store.setSessions(sessions);
    return { token, user };
}

// ---------------------------------------------------------------------
// Connection
// ---------------------------------------------------------------------
let lastSync = null;
let syncing = false;
let localDay = null; // a day started on this till while offline

async function ping() {
    try {
        await cloud.hello({ synced: false });
        return true;
    } catch (e) {
        return false;
    }
}

async function syncDown() {
    const etagFile = path.join(dataDir, 'etag.txt');
    let etag = null;
    try { etag = fs.readFileSync(etagFile, 'utf8').trim(); } catch (e) {}
    const r = await cloud.bootstrap(etag);
    if (r.unchanged) return { unchanged: true };
    store.setCache(r.data);
    if (r.etag) { try { fs.writeFileSync(etagFile, r.etag); } catch (e) {} }
    if (r.data && r.data.day && r.data.day.day) localDay = null; // the server's day wins
    return { items: (r.data.items || []).length, employees: (r.data.employees || []).length };
}

const ROUTES = {
    sale: { method: 'POST', path: () => '/api/pos/sales' },
    returnCash: { method: 'POST', path: () => '/api/pos/returns/cash' },
    returnAccount: { method: 'POST', path: () => '/api/pos/returns/account' },
    cashMovement: { method: 'POST', path: () => '/api/pos/cash/movements' },
    dayStart: { method: 'POST', path: () => '/api/pos/day/start' },
    dayClose: { method: 'POST', path: () => '/api/pos/day/close' },
    dayContinue: { method: 'POST', path: () => '/api/pos/day/continue' },
    dayRollover: { method: 'POST', path: () => '/api/pos/day/rollover' },
    basketCancel: { method: 'POST', path: () => '/api/pos/basket/cancel' },
    stockTakeLines: { method: 'PUT', path: (job) => `/api/pos/stocktakes/${job.body.stockTakeId}/lines` },
    stockTakeSubmit: { method: 'POST', path: (job) => `/api/pos/stocktakes/${job.body.stockTakeId}/submit` }
};

// Sends the outbox in order. A job the server refuses is parked in Failed for an administrator.
async function syncUp() {
    const list = store.outbox();
    if (!list.length) return { sent: 0, failed: 0, left: 0 };
    const keep = [];
    let sent = 0, failed = 0;

    for (const job of list) {
        const route = ROUTES[job.type];
        if (!route) { keep.push(job); continue; }
        try {
            const res = await cloud.asUser(job.userId, route.method, route.path(job), job.body, 30000);
            if (res.status === 401 || res.status === 403) { keep.push(job); break; }
            if (res.ok) {
                const body = await res.json().catch(() => ({}));
                sent++;
                if (body && (body.sale || body.movement)) {
                    store.addReceipt({ at: job.createdAt, type: job.type, offlineNumber: job.offlineNumber || null, server: body.sale || body.movement });
                }
                log(`Sent ${job.type} ${job.offlineNumber || ''} -> ${(body.sale && body.sale.SaleNumber) || (body.movement && body.movement.MovementNumber) || 'ok'}`);
            } else if ([400, 404, 409, 422].includes(res.status)) {
                let reason = `Rejected by the server (${res.status})`;
                try { const d = await res.json(); reason = d.error || d.message || reason; } catch (e) {}
                job.failedReason = reason;
                job.failedAt = new Date().toISOString();
                store.addFailed(job);
                failed++;
                log(`FAILED ${job.type} ${job.offlineNumber || ''}: ${reason}`);
            } else {
                job.attempts = (job.attempts || 0) + 1;
                keep.push(job);
            }
        } catch (e) {
            job.attempts = (job.attempts || 0) + 1;
            keep.push(job);
        }
    }
    store.setOutbox(keep);
    return { sent, failed, left: keep.length };
}

async function syncNow(reason) {
    if (syncing) return { busy: true };
    syncing = true;
    try {
        await cloud.hello({ synced: true });
        const up = await syncUp();
        const down = await syncDown();
        lastSync = new Date().toISOString();
        log(`Sync (${reason}): sent ${up.sent}, failed ${up.failed}, waiting ${up.left}`);
        return { ok: true, up, down, lastSync };
    } catch (e) {
        log(`Sync (${reason}) could not finish: ${e.message}`);
        return { ok: false, error: e.message };
    } finally {
        syncing = false;
    }
}

// ---------------------------------------------------------------------
// The POS web files (downloaded once, then kept up to date)
// ---------------------------------------------------------------------
const webDir = path.join(dataDir, 'web');
fs.mkdirSync(path.join(webDir, 'css'), { recursive: true });

async function refreshWeb() {
    for (const name of WEB_FILES) {
        try {
            const buf = await cloud.webFile(name);
            fs.mkdirSync(path.dirname(path.join(webDir, name)), { recursive: true });
            fs.writeFileSync(path.join(webDir, name), buf);
        } catch (e) {
            log(`Could not refresh ${name}: ${e.message}`);
        }
    }
}

function serveWeb(res, name) {
    const file = path.join(webDir, name);
    if (!fs.existsSync(file)) {
        // Fall back to the copy packed into the installer
        const packed = path.join(__dirname, 'web', name);
        if (!fs.existsSync(packed)) return send(res, 404, { error: `${name} is not on this till yet. Connect to the internet once.` });
        return sendFile(res, packed);
    }
    sendFile(res, file);
}

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json' };
function sendFile(res, file) {
    const body = fs.readFileSync(file);
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(body);
}
function send(res, status, body) {
    const text = JSON.stringify(body);
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' });
    res.end(text);
}

module.exports = { store, cloud, syncNow, log, config, VERSION };

// The rest of the server (routing) lives in server-routes.js so this file stays readable
require('./lib/routes')({ config, store, cloud, Offline, log, send, serveWeb, refreshWeb, sessionUser, signIn, syncNow, syncDown, state: () => ({ lastSync, syncing, online: cloud.online, localDay }), setLocalDay: (d) => { localDay = d; }, getLocalDay: () => localDay, VERSION, dataDir, appDir });
